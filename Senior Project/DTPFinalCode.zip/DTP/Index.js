
const express = require('express')           
const app = express()                        
const http = require('http').Server(app);     
const io = require('socket.io')(http);       
const port = 3000                            
const path = require('path')                 
const pug = require('pug')                    
const cookieParser = require('cookie-parser')  
const cookie = require("cookie")          
var mysql = require('mysql');            
const { emit } = require('cluster');     
const { finished } = require('stream');  
const { isNullOrUndefined } = require('util'); 
//const DTPSQL = require('./DTPSQL.js');
//const { finished } = require('stream');

/* Adding queues for queue-up This was placed a top of the code begining the DTP Node Server as an attempt to practice creating a function 
   outside the scope of the posts sent from client. It takes in the original req from
   the user post to queue up, the response of the Node web server, and the results from the previous function.  
*/
function addingQueuesForEach(req, res, finishedQueues) {  
    Object.keys(req.body).forEach(element => {
        elementArray = element.split(':')
        var game_name = elementArray[0]
        var gamemode_name = elementArray[1]
        //console.log(game_name + " " + gamemode_name + " " + req.body[element][0] + " " + req.user_id)
        connection.query('SELECT `game`.`game_id`, `gamemode_id`, `gamemode_nop` FROM `dtp`.`game`, `dtp`.`gamemode` WHERE game_name = ? AND gamemode_name = ?;', [game_name, gamemode_name], function (error, gameModeResults, fields) {
            if (error) {
                console.log("App Post: Queue Up: Adding Queues: Error occurred with SELECT query")
                //return res.sendFile(path.join(__dirname, "./HTML/DTPQueueHostError.html"))
            }
            else if (gameModeResults[0] == undefined) {
                console.log("App Post: Queue Up: Adding Queues: game_id and gamemode_id do not match")
                //return res.sendFile(path.join(__dirname, "./HTML/DTPQueuePlayerError.html"))
            }
            else {
                //if host
                if (req.body[element][0] != 0) {
                    var queueToken = makeid(10)
                    connection.query("INSERT INTO `dtp`.`queuedplayer`(`game_id`, `gamemode_id`, `user_id`, `user_is_host`, `user_queued_time`, `user_queue_token`) VALUES(?, ?, ?, ?, NOW(), ?);", [gameModeResults[0].game_id, gameModeResults[0].gamemode_id, req.user_id, req.body[element][0], queueToken], function (error, queuedResults, fields) {
                        if (error) {
                            console.log("App Post: Queue Up: Adding Queues: If Host: Insert Host Query Error")
                            res.sendFile(path.join(__dirname, "./HTML/DTPQueueHostError.html"))
                        }
                        else {
                            console.log("App Post: Queue Up: Adding Queues: If Host: Adding Queues Successful")
                            connection.query("UPDATE queuedplayer AS QP, (SELECT QP.user_id FROM dtp.queuedplayer AS QP, dtp.gamemode AS GM WHERE QP.game_id = ? AND QP.gamemode_id = ? AND QP.game_id = GM.game_id AND QP.gamemode_id = GM.gamemode_id AND QP.user_queue_token IS NULL ORDER BY user_queued_time ASC LIMIT ?) AS AP SET user_queue_token = ? WHERE QP.user_id = AP.user_id AND QP.game_id = ? AND QP.gamemode_id = ?;", [gameModeResults[0].game_id, gameModeResults[0].gamemode_id, (gameModeResults[0].gamemode_nop - 1), queueToken, gameModeResults[0].game_id, gameModeResults[0].gamemode_id], function (error, updateResults, fields) {
                                if (error) {
                                    console.log("App Post: Queue UP: Adding Queues: If Host: Error in Update Availble Players Queue Tokens")
                                }
                                else {
                                    console.log("App Post: Queue Up: Adding Queues: If Host: Available Player Queue Tokens Updated")
                                    //connection.query("SELECT Count(user_id) AS NOQP FROM dtp.queuedplayer WHERE user_queue_token = ?",
                                    console.log(" If Host: queuedtoken: " + queueToken)
                                    connection.query("SELECT Count(QP.user_id) AS C, username FROM dtp.queuedplayer AS QP, `dtp`.`user` AS U WHERE QP.user_id = U.user_id AND QP.user_queue_token = ? GROUP BY QP.user_id;", [queueToken], function (error, countResults, fields) {
                                        if (error) {
                                            console.log("App Post: Queue Up: Adding Queues: If Host: Error in Select Count")
                                        }
                                        else
                                            if (countResults.length == gameModeResults[0].gamemode_nop) {
                                                console.log("App Post: Queue Up: Adding Queues: If Host: Number of Players Queued Equals Gammemode NOP")
                                                //Emit Message Box Stating Queue is Full and Ready to Accept
                                                // Create an array with all of the usernames 
                                                //username_array = []
                                                //username_array.push('User_1')
                                                //io.to(queueToken).emit('test')
                                                //io.to(queueToken).emit('QFull')
                                                //TO ALERT ALL USERS BY USERNAME
                                                setTimeout(() => {
                                                    console.log("If Host: SetTimeOUT for QFull")
                                                    console.log(countResults)
                                                    console.log(countResults[1])
                                                    countResults.forEach(element => {
                                                        console.log(element.username)
                                                        io.to(element.username).emit('refresh')
                                                    })
                                                }, 10000)
                                                //TO CHECK FOR ACCEPTED PLAYERS
                                                setTimeout(() => {
                                                    console.log("App Post: Queue Up: Adding Queues: If Host: SetTimeOUT for Accepted")
                                                    connection.query("SELECT player_accepted_match, username, user_is_host FROM dtp.queuedplayer AS QP, `user` AS U WHERE QP.user_id = U.user_id AND user_queue_token = ?;", [queueToken], function (error, acceptedResults, fields) {
                                                        if (error) {
                                                            console.log("App Post: Queue Up: Adding Queues: If Host: Error in Select player_accepted_match")
                                                        }
                                                        else {
                                                            console.log("App Post: Queue Up: Adding Queues: If Host: Selecting player_accepted_match successful")
                                                            var accepted_counter = 0;
                                                            acceptedResults.forEach(element => {
                                                                //if (element.player_accepted_match == 0 && element.user_is_host == 1) { if not accept and is host
                                                                if (element.player_accepted_match == 0) {
                                                                    connection.query('UPDATE queuedplayer AS QP, (SELECT user_queue_token FROM dtp.queuedplayer AS QP, dtp.`user` AS U WHERE U.username = ?  AND QP.user_is_host = 1 and Qp.user_id = U.user_id) AS AP SET QP.user_queue_token = NULL WHERE QP.user_queue_token = AP.user_queue_token;', [element.username], function (error, updateResults, fields) {
                                                                        if (error) {
                                                                            console.log("App Post: Queue Up: Adding Queues: If Host: Error has occured in connection UPDATE Query")
                                                                        }
                                                                        else {
                                                                            console.log("App Post: Queue Up: Adding Queues: If Host: Update setting player queue tokens to NULL")
                                                                            connection.query('DELETE FROM `dtp`.`queuedPlayer` WHERE user_id = (SELECT user_id From dtp.`user` Where username = ?);', [element.username], function (error, deleteResults, fields) {
                                                                                if (error) {
                                                                                    console.log("App Post: Queue Up: Adding Queues: If Host: Error has occured in connection DELETE query")
                                                                                }
                                                                                else {
                                                                                    console.log("App Post: Queue Up: Adding Queues: If Host: Queues for user deleted.")
                                                                                    //console.log(results[0].user_last_login)
                                                                                    //console.log(req.body)
                                                                                    //console.log("AddingQueues:  " + Object.keys(req.body).length) 
                                                                                    io.to(user_queue_token).emit('refresh', ("A player/host has not responded in time"))
                                                                                }
                                                                            });
                                                                        }
                                                                    });
                                                                }
                                                                else {
                                                                    accepted_counter++;

                                                                }
                                                            })
                                                            console.log("accepted_counter: " + accepted_counter)
                                                            console.log("gamemode nop: " + gameModeResults[0].gamemode_nop)
                                                            if (accepted_counter == gameModeResults[0].gamemode_nop) {
                                                                console.log("App Post: Queue Up: Adding Queues: If Host: if accepted_counter = gamemode.NOP")
                                                                acceptedResults.forEach(element => {
                                                                    console.log("element.username: " + element.username + ", queueToken: " + queueToken)
                                                                    connection.query("DELETE FROM `dtp`.`queuedPlayer` WHERE user_id = (SELECT user_id From dtp.`user` Where username = ?) AND user_queue_token NOT IN (?);", [element.username, queueToken], function (error, deleteResults, fields) {
                                                                        if (error) {
                                                                            console.log("App Post: Queue Up: Adding Queues: If Host: if accepted_counter = gamemode.NOP Delete Error")
                                                                        }
                                                                        else {
                                                                            console.log(element.username)
                                                                            io.to(element.username).emit('refresh', ("You have found a match!"))
                                                                        }
                                                                    });
                                                                })
                                                            }
                                                        }
                                                    });


                                                }, 30000)
                                            }

                                    });

                                }
                            });
                            // console.log("User and Gamemode Queue added to DB")
                            finishedQueues[0] = finishedQueues[0] + 1
                            //console.log(finishedQueues[1])
                            if (finishedQueues[0] == Object.keys(req.body).length) {
                                console.log("App Post: Queue Up: Adding Queues: If Host: All queues have been added")
                                //res.redirect('/DTPMyQueues.html')
                                //finishedQueues[1] = true
                            }
                        }
                    });
                }
                else {
                    //if player
                    connection.query("INSERT INTO `dtp`.`queuedplayer`(`game_id`, `gamemode_id`, `user_id`, `user_is_host`, `user_queued_time`) VALUES(?, ?, ?, ?, NOW());", [gameModeResults[0].game_id, gameModeResults[0].gamemode_id, req.user_id, req.body[element][0]], function (error, queuedResults, fields) {
                        if (error) {
                            console.log("App Post: Queue Up: Adding Queues: If Player: Insert player query error")
                            res.sendFile(path.join(__dirname, "./HTML/DTPQueueHostError.html"))
                        }
                        else {
                            console.log("App Post: Queue Up: If Player: Insert into QP sucessful")
                            connection.query("UPDATE queuedplayer SET user_queue_token = (SELECT user_queue_token FROM (SELECT QP.user_queue_token, GM.gamemode_nop - COUNT(user_queue_token) AS RA FROM queuedplayer AS QP, gamemode AS GM WHERE QP.game_id = ? AND QP.gamemode_id = ? AND QP.game_id = GM.game_id AND QP.gamemode_id = GM.gamemode_id GROUP BY user_queue_token ORDER BY user_queued_time ASC) AS RAQuery WHERE RAQuery.Ra > 0 and user_queue_token is not null LIMIT 1) WHERE user_id = ? AND game_id = ? AND gamemode_id = ?;", [gameModeResults[0].game_id, gameModeResults[0].gamemode_id, req.user_id, gameModeResults[0].game_id, gameModeResults[0].gamemode_id], function (error, updateResults, updateFields) {
                                if (error) {
                                    console.log("App Post: Queue Up: Adding Queues: If Player: Update queue token error")
                                    //res.sendFile(path.join(__dirname, "./HTML/DTPQueueHostError.html"))
                                }
                                else {
                                    console.log("App Post: Queue Up: Adding Queues: If Player: update for player to avaiable room successful")
                                    connection.query("SELECT Count(user_id) AS NOQP FROM dtp.queuedplayer WHERE user_queue_token = ?", [req.user_id], function (error, countResults, fields) {
                                        if (error) {
                                            console.log("App Use: Queue Up: Adding Queues: If Player: Error in Select Count")
                                        }
                                        else
                                            if (countResults[0].NOQP == gameModeResults[0].gamemode_nop) {
                                                console.log("App Post: Queue Up: Adding Queues: If Host: Number of Players Queued Equals Gammemode NOP")
                                                //Emit Message Box Stating Queue is Full and Ready to Accept
                                                // Create an array with all of the usernames 
                                                //username_array = []
                                                //username_array.push('User_1')
                                                //io.to(queueToken).emit('test')
                                                //io.to(queueToken).emit('QFull')
                                                setTimeout(() => {
                                                    console.log("App Post: Queue Up: Adding Queues: If Player: SetTimeOUT Reached")
                                                    countResults.forEach(element => {
                                                        io.to(element.username).emit('refresh')
                                                    }, 10000)
                                                })
                                            }
                                    });

                                    finishedQueues[0] = finishedQueues[0] + 1
                                    //console.log(finishedQueues[1])
                                    if (finishedQueues[0] == Object.keys(req.body).length) {
                                        console.log("App Post: Queue Up: Adding Queues: If Player: All queues have been added")
                                        //res.redirect('/DTPMyQueues.html')
                                        //finishedQueues[1] = true
                                    }
                                }
                            });
                        }
                    });
                }
            }
        });




    })
}
/*
 These are attempts to use other js files to practice doing so and to attempt to improve readability, which helped a little.
 */ 
const connection = require('./DTPConnection.js').connection
const User = require('./DTPConnection.js').User
const Queue = require('./DTPConnection.js').Queue

//Creates a connection to the MySQl Server
//var connection = mysql.createConnection({
//    host: 'localhost',
//    user: 'root',
//    password: '123321',
//    database: 'dtp',
//    insecureAuth: true
//});

var activeUsers = []


/*
 * This function is used to create a random user_queue_token for hosted rooms and user_auth_tokens. In other words, whenever i needed to 
 * add a unqiue id for the data found in the DB entity queuedplayer identify a user specific to some random algorithm sufficent for the scope of this project. 
 * NOTE: The true purpose for this project was to attempt a client userface that allows a user 
*/
function makeid(length) {
    var result = '';
    var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var charactersLength = characters.length;
    for (var i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
}

//connection.connect();
app.use(cookieParser())
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static("Public"));
app.use(express.static("HTML"));
app.set('view engine', 'pug')
var socketid

//io.on('connection', (socket) => {
//    console.log(socket.id)
//    console.log('a user connected: ' + socket.id);
//    const cookies = cookie.parse(socket.request.headers.cookie || "");
//    console.log(cookies)
//});

//io.on('connection', (socket) => {
//    socket.on('chat message', (msg) => {
//        io.emit('chat message', msg);
//    });
//});

//io.on('connection', (socket) => {
//    console.log(socket.id)
//    socketid = socket.id
//    console.log('a user connected: ' + socket.id);
//    const cookies = cookie.parse(socket.request.headers.cookie || "");
//    console.log(cookies)
//});

//Takes token to add username to socket for socket.io connections
//io.use((socket, next) => {
//token = socket.handshake.auth.token.split('=')[1]
//console.log(" io.use: " + token)
//socket.token = token
//next()
//username
//socket.username = ""
//connection.query('Select `username`, `user_token`, (`user_last_login`- NOW()) AS TimeDiff FROM `dtp`.`user` WHERE `user_token`= ?;', [token], function (error, results, fields) {
//    if (error) {
//        console.log("Error has occured in connection query")
//    }
//    else if (results[0] == undefined) {
//        console.log("Results Undefined for io use")
//    }
//    else {
//        console.log('User Crendentials Match');
//        //activeUsers.push({userdata: results[0], token: token})
//         //console.log(activeUsers)
//        if ((results[0].TimeDiff > -3000)) {
//            connection.query('UPDATE `dtp`.`user` SET user_last_login = (NOW()) WHERE `user_token` = ?;', [token], function (error, results, fields) {
//                if (error) {
//                    console.log('Error in token and datetime update')
//                }
//            });
//            socket.username = results[0].username
//            console.log(socket.username)
//        }
//        else {
//            console.log("User Login Session Expired")
//        }
//        next()
//    }
//});
//})








/*
io.on('msgTo', (socket) => {
    io.emit(console.log("On msgTo: " + socket))

})
*/


//Assignes a cookie with unique token for every connection
app.use((req, res, next) => {
    console.log("App Use: Route Requested: " + req.path)
    let cookies = req.cookies

    // If there is no cookie
    if (!cookies.token) {
        console.log("App Use: No token cookie found")
        res.cookie('token', makeid(10), { maxAge: 3600000 })
        req.requiresLogIn = true
        next()
    }

    // If there is a cookie
    else {
        console.log("App Use: cookie found")

        // get user's login data
        User.getUserLoginData(req.cookies.token)
            .then(
                function completed(firstResults) {
                    console.log('App Use: User Credentials Match');

                    if ((firstResults[0].TimeDiff > -3000)) {
                        // if the user's last login is recent, refresh the last login
                        console.log('App Use: User TimeDiff > -3000')

                        User.updateUserLastLogin(req.cookies.token)
                            .then(
                                function completed(message) {
                                    console.log(message)
                                    req.username = firstResults[0].username
                                    req.user_id = firstResults[0].user_id
                                    next()
                                },
                                function failed(error) {
                                    console.log(error)
                                    req.requiresLogIn = true
                                    next()
                                }
                            )
                    }
                    else {
                        // if the user's last login is stale, set user token to null and remove any queues the user is in
                        console.log("App Use: User Login Session Expired")

                        User.setUserTokenToNull(firstResults[0].user_id)
                            .then(
                                function completed(message) {
                                    console.log(message)
                                    return Queue.deleteUsersQueues(firstResults[0].user_id)
                                },
                                function failed(error) {
                                    console.log(error)
                                    req.requiresLogIn = true
                                    next()
                                }
                            )
                            .then(
                                function completed(message) {
                                    console.log(message)
                                    req.requiresLogIn = true
                                    next()
                                },
                                function failed(error) {
                                    console.log(error)
                                }
                            )
                    }
                },
                function failed(error) {
                    console.log(error)
                    req.requiresLogIn = true
                    next()
                }
            )
    }
})


io.on('connection', (socket) => {
    console.log("Io On: Connection: User connected: " + socket.token + socket.username)
    //socket.join(socket.username)
    console.log(socket.rooms)

    // on msgTo
    socket.on('msgTo', (msg) => {
        console.log(msg)
        socket.to('michael').emit('msg', 'world')
    })

    // on set up
    socket.on('setup', (cookie) => {
        cookie = cookie.split('=')[1]
        console.log('SET UP COOKIE', cookie)
        //joins user to rooms and personal room
        connection.query('Select `username`, `dtp`.`user`.`user_id`, `user_token`, (`user_last_login`- NOW()) AS TimeDiff, `user_queue_token`  FROM `dtp`.`user`, `dtp`.`queuedplayer` WHERE `user_token`= ? AND `dtp`.`user`.`user_id` = `dtp`.`queuedplayer`.`user_id`;', [cookie], function (error, firstResults, firstFields) {
            if (error) {
                console.log("Io on: Socket on: Setup: Error has occured in select query")
                //req.requiresLogIn = true
                //next()
            }
            else if (firstResults[0] == undefined) {
                console.log("Io on: Socket on: Setup: Results Undefined")
                //req.requiresLogIn = true
                //next()
            }
            else {
                console.log('Io on: Socket on: Setup: User Credentials Match');
                //activeUsers.push({userdata: results[0], token: token})
                // console.log(activeUsers)
                firstResultsArray = firstResults
                if ((firstResults[0].TimeDiff > -3000)) {
                    connection.query('UPDATE `dtp`.`user` SET user_last_login = (NOW()) WHERE `user_token` = ?;', [cookie], function (error, results, fields) {
                        if (error) {
                            console.log('Io on: Socket on: Setup: Error in token and datetime update')
                            //req.requiresLogIn = true
                            //next()
                        }

                        //req.username = firstResults[0].username
                        //req.user_id = firstResults[0].user_id
                        //next()
                        console.log("Socket On: Setup: " + firstResults[0].username)
                        socket.join(firstResults[0].username)

                        //console.log(socket.rooms)
                        io.to(firstResults[0].username).emit('test')
                        io.to(firstResults[0].username).emit('setUsername', firstResults[0].username)
                        firstResults.forEach((ele) => {
                            if (ele.user_queue_token == null) {
                                //do nothing
                            }
                            else {
                                socket.join(ele.user_queue_token)
                            }
                        })
                        console.log(socket.rooms)
                        firstResults.forEach((ele) => {
                            if (ele.user_queue_token == null) {
                                //do nothing
                            }
                            else {
                                //console.log("Potential Full Queue with token: " + ele.user_queue_token)
                                connection.query('Select TC.user_queue_token, QP.player_accepted_match, QP.user_id, U.username FROM (SELECT user_queue_token, Count(user_queue_token) AS PC, gamemode_nop AS NOP FROM dtp.queuedplayer AS QP, dtp.gamemode AS GM WHERE QP.game_id = GM.game_id AND QP.gamemode_id = GM.gamemode_id AND QP.user_queue_token = ? GROUP BY user_queue_token) AS TC, queuedplayer AS QP, `user` AS U WHERE PC = NOP AND QP.user_queue_token = TC.user_queue_token AND U.user_id = QP.user_id;', [ele.user_queue_token], function (error, results, fields) {
                                    if (error) {
                                        console.log("Io On: Socket On: Setup: Checking room filled error")
                                    }
                                    else if (results[0] == undefined) {
                                        console.log("results undefined")
                                    }
                                    else
                                        results.forEach(element => {
                                            if (element.player_accepted_match != 1) {
                                                io.to(element.username).emit('QFull', ele.user_queue_token)
                                            }
                                        })

                                });
                            }
                        })

                    });
                }
                else {
                    console.log("Io on: Socket on: Setup: Expired")
                    connection.query('UPDATE user SET user_token = null WHERE user_id = ?;', [firstResultsArray[0].user_id], function (error, userResults, fields) {
                        if (error) {
                            console.log("Io on: Socket on: Setup: Login Session Expired: Error has occured in connection query")
                            //req.requiresLogIn = true
                            //next()
                        }
                        else {
                            console.log("App Use: Set user_token = null.")
                        }
                    });
                    connection.query('DELETE FROM `dtp`.`queuedPlayer` WHERE user_id = ?;', [firstResultsArray[0].user_id], function (error, userResults, fields) {
                        if (error) {
                            console.log("App Use: Delete: Error has occured in connection query")
                        }
                        else
                            console.log("App Use: Queues for user deleted.")
                    });
                    //req.requiresLogIn = true
                    //next()
                }

            }

        });

    })

    // receive chat messages
    socket.on('chat message', (msg) => {
        console.log('chat message received', msg)
        io.to(msg.roomToken).emit('chat message', msg)
    })

    socket.on('acceptQ', (msg) => {
        console.log(msg)
        token = msg.cookie.split('=')[1]
        user_queue_token = msg.user_queue_token
        reply = msg.reply
        console.log(token + ":" + user_queue_token + ":" + reply)
        connection.query('UPDATE queuedplayer AS QP, `user` AS U SET player_accepted_match = ? WHERE U.user_token = ? AND user_queue_token = ? AND U.user_id = QP.user_id;', [reply, token, user_queue_token], function (error, results, fields) {
            if (error) {
                console.log("IO On: Socket On: acceptQ: Error in Update")
            }
            else {
                console.log("IO On: Socket On: acceptQ: Update successful")

            }
        });
    })

    socket.on('rejectQ', (msg) => {
        console.log(msg)
        token = msg.cookie.split('=')[1]
        user_queue_token = msg.user_queue_token
        reply = msg.reply
        console.log(token + ":" + user_queue_token + ":" + reply)
        console.log("Socket on: rejectQ: Before Delete")
        //connection.query('DELETE FROM `dtp`.`queuedPlayer` WHERE (`user_queued_time`- NOW() < -3000) OR user_id = ?;', [req.user_id], function (error, deleteResults, fields) {
        connection.query('UPDATE queuedplayer AS QP, (SELECT user_queue_token FROM dtp.queuedplayer AS QP, dtp.`user` AS U WHERE U.username = ?  AND QP.user_is_host = 1 and Qp.user_id = U.user_id) AS AP SET QP.user_queue_token = NULL WHERE QP.user_queue_token = AP.user_queue_token;', [msg.username], function (error, updateResults, fields) {
            if (error) {
                console.log("Socket on: rejectQ: Error has occured in connection UPDATE Query")
            }
            else {
                console.log("Socket on: rejectQ:  UPDATE set user_queue_token to NULL successful")
                connection.query('UPDATE queuedplayer AS QP SET QP.player_accepted_match = 0 WHERE QP.user_queue_token IS NULL;', function (error, results, fields) {
                    if (error) {
                        console.log("Socket on: rejectQ: Update player_accepted_match to 0 error")
                    }
                    else {
                        console.log("Socket on: rejectQ: Update player_accepted_match to 0 successful")
                        connection.query('DELETE FROM `dtp`.`queuedPlayer` WHERE user_id = (SELECT user_id From dtp.`user` Where username = ?);', [msg.username], function (error, deleteResults, fields) {
                            if (error) {
                                console.log("Socket on: rejectQ: Error has occured in connection DELETE query")
                            }
                            else {
                                console.log("Socket on: rejectQ: Queues for user deleted.")
                                //console.log(results[0].user_last_login)
                                //console.log(req.body)
                                //console.log("AddingQueues:  " + Object.keys(req.body).length) 
                                io.to(user_queue_token).emit('refresh')
                            }
                        });
                    }
                });
            }
        });
    })

})





    //app.get('/socketTest', (req, res) => {
    //    token = makeid(5)
    //    res.cookie("Token", token, { maxAge: 360000 }).cookie("SocketID", socketid).sendFile(path.join(__dirname, "./HTML/socketTest.html"));
    //})

    //List of routes for redirect
    //Route to DTPSignIn.html
    app.get('/', (req, res) => {
        console.log(pug.renderFile((process.cwd() + '/PUG/login.pug')))
        //res.sendFile(path.join(__dirname, "./HTML/DTPSignIn.html"))
        res.send(pug.renderFile((process.cwd() + '/PUG/login.pug')))
    })
    //Route to DTPSignInCreate.html
    app.get('/DTPSignInCreate.html', (req, res) => {
        res.sendFile(path.join(__dirname, "./HTML/DTPSignInCreate.html"))
    })
    //Route to DTPSignInError.html
    app.get('/DTPSignInError.html', (req, res) => {
        res.sendFile(path.join(__dirname, "./HTML/DTPSignInError.html"))
    })
    //Route to DTPSignInTimedOut.html
    app.get('/DTPSignInTimedOut.html', (req, res) => {
        res.sendFile(path.join(__dirname, "./HTML/DTPSignInTimedOut.html"))
    })
    //Route to DTPRegister.html
    app.get('/DTPRegister.html', (req, res) => {
        res.sendFile(path.join(__dirname, "./HTML/DTPRegister.html"))
    })
    //Route to DTPRegisterError.html
    app.get('/DTPRegisterError.html', (req, res) => {
        res.sendFile(path.join(__dirname, "./HTML/DTPRegisterError.html"))
    })
    //Route to DTPHome.html
    app.get('/DTPHome.html', (req, res) => {
        if (req.requiresLogIn == true) {
            return res.redirect('/')
        }
        else
            // res.send(pug.renderFile((process.cwd() + '/Pug/DTP.pug')))
            res.send(pug.renderFile((process.cwd() + '/Templates/DTPHome.pug')))
    })

    app.get('/DTPAbout.html', (req, res) => {
        if (req.requiresLogIn == true) {
            return res.redirect('/')
        }
        else
            // res.send(pug.renderFile((process.cwd() + '/Pug/DTP.pug')))
            res.send(pug.renderFile((process.cwd() + '/Templates/DTPAbout.pug')))
    })

    app.get('/DTPSupport.html', (req, res) => {
        if (req.requiresLogIn == true) {
            return res.redirect('/')
        }
        else
            // res.send(pug.renderFile((process.cwd() + '/Pug/DTP.pug')))
            res.send(pug.renderFile((process.cwd() + '/Templates/DTPSupport.pug')))
    })


    //Route to DTPMyFriends.html
    app.get('/DTPMyFriends.html', (req, res) => {
        if (req.requiresLogIn == true) {
            return res.redirect('/')
        }
        console.log(req.cookies.token)

        User.getFriends(req.cookies.token).then(
            function completed(friendList) {
                return res.send(pug.renderFile((process.cwd() + '/Templates/DTPMyFriends.pug'), { friendList }))
            },
            function failed(error) {
                console.log(error)
            }
        )

        //var friendList = []


        //var promise = new Promise((suc, fail) => {
        //    connection.query('SELECT `dtp`.`user`.`username`, `dtp`.`user`.`user_email` FROM dtp.friend, dtp.user, (SELECT`dtp`.`user`.`user_id` FROM`dtp`.`user` WHERE`user_token` = ?) AS UserId WHERE(dtp.friend.user_id = UserId.user_id AND dtp.friend.friend_id = dtp.user.user_id) OR(dtp.friend.friend_id = UserId.user_id AND dtp.friend.user_id = dtp.user.user_id);', [req.cookies.token], function (error, results, fields) {
        //        if (error) fail(error)

        //        else if (results[0] == undefined) {
        //            console.log("error")
        //            fail("undefined error")
        //        }
        //        else
        //            console.log("Reached Here: " + results)

        //        results.forEach(element => {
        //            friend = {
        //                'friend_name': element.username,
        //                'friend_email': element.user_email
        //            }
        //            friendList.push(friend)
        //        })
        //        //console.log(queueList)
        //        //console.log(pug.renderFile(process.cwd() + '/Templates/DTPMyQueues.pug', { queueList }))
        //        //return res.send(pug.renderFile((process.cwd() + '/Templates/DTPMyFriends.pug'), { friendList }))

        //        suc(friendList)
        //    });
        //})

        //promise.then(
        //    function completed(friendList) {
        //        return res.send(pug.renderFile((process.cwd() + '/Templates/DTPMyFriends.pug'), { friendList }))
        //    },
        //    function failed(error) {
        //        console.log(error)
        //    }

        //)






        //connection.query('SELECT `dtp`.`user`.`username`, `dtp`.`user`.`user_email` FROM dtp.friend, dtp.user, (SELECT`dtp`.`user`.`user_id` FROM`dtp`.`user` WHERE`user_token` = ?) AS UserId WHERE(dtp.friend.user_id = UserId.user_id AND dtp.friend.friend_id = dtp.user.user_id) OR(dtp.friend.friend_id = UserId.user_id AND dtp.friend.user_id = dtp.user.user_id);', [req.cookies.token], function (error, results, fields) {
        //    if (error) throw error
        //    else if (results[0] == undefined) {
        //        console.log("error")
        //    }
        //    else
        //        console.log("Reached Here: " + results)
        //    results.forEach(element => {
        //        friend = {
        //            'friend_name': element.username,
        //            'friend_email': element.user_email
        //        }
        //        friendList.push(friend)
        //    })
        //    //console.log(queueList)
        //    //console.log(pug.renderFile(process.cwd() + '/Templates/DTPMyQueues.pug', { queueList }))
        //    return res.send(pug.renderFile((process.cwd() + '/Templates/DTPMyFriends.pug'), { friendList }))
        //});
    })
    //Route to HelloW
    app.get('/helloW', (req, res) => {
        res.sendFile(path.join(__dirname, "./HTML/HelloW.html"))
    })
    //Route to DTPQueueUp
    app.get('/DTPQueueUp.html', (req, res) => {
        if (req.requiresLogIn == true) {
            return res.redirect('/')
        }
        //console.log(req.cookies.token)
        var gameAndGamemodeList = []
        var gameOnlyList = []
        var currentGame
        connection.query('SELECT DISTINCT `game_name`, `gamemode_name`, `gamemode_nop` FROM`dtp`.`game`, `dtp`.`gamemode` WHERE`dtp`.`game`.`game_id` = `dtp`.`gamemode`.`game_id` ORDER BY `game_name` ASC ;', function (error, results, fields) {
            if (error) throw error
            else if (results[0] == undefined) {
                res.redirect('/DTPHome.html')
            }
            else {
                console.log("App Get: DTPQueueUp: Select distinct query successful")
                //first fill first game in gameOnlyList
                currentGame = results[0].game_name
                gameOnlyList.push({ 'game_name': results[0].game_name })
                results.forEach(element => {
                    gameOnly = {
                        'game_name': element.game_name
                    }
                    if (gameOnly.game_name == currentGame) {
                        //console.log("Do Nothing")
                    }
                    else {
                        currentGame = gameOnly.game_name
                        gameOnlyList.push(gameOnly)
                        console.log("GameOnly.game_name: " + gameOnly.game_name)
                    }
                })
                //console.log(gameOnlyList)
                results.forEach(element => {
                    gameAndGamemode = {
                        'game_name': element.game_name,
                        'gamemode_name': element.gamemode_name,
                        'gamemode_nop': element.gamemode_nop
                    }
                    gameAndGamemodeList.push(gameAndGamemode)
                })
                console.log(gameAndGamemodeList)
                //console.log(pug.renderFile(process.cwd() + '/Templates/DTPMyQueueUpO.pug', { gameAndGamemodeList }))
                return res.send(pug.renderFile((process.cwd() + '/Templates/DTPQueueUp.pug'), { gameAndGamemodeList, gameOnlyList }))
            }
        });
        //res.sendFile(path.join(__dirname, "./HTML/DTPQueueUp.html"))
    })

    //Route to socketTest.html
    app.get('/socketTest.html', (req, res) => {
        res.sendFile(path.join(__dirname, "./HTML/socketTest.html"))
    })

    //Route to DTPMyQueues.html
    app.get('/DTPMyQueues.html', (req, res) => {
        if (req.requiresLogIn == true) {
            return res.redirect('/')
        }
        else {
            //console.log(req.cookies.token)
            var queueList = []
            connection.query('SELECT DISTINCT `game_name`, `gamemode_name`, `gamemode_nop`, `user_queue_token` FROM `dtp`.`queuedplayer`, `dtp`.`game`, `dtp`.`gamemode` WHERE `dtp`.`game`.`game_id` = `dtp`.`queuedPlayer`.`game_id` AND `dtp`.`gamemode`.`gamemode_id` = `dtp`.`queuedplayer`.`gamemode_id` AND `dtp`.`game`.`game_id` = `dtp`.`gamemode`.`game_id` AND `dtp`.`queuedplayer`.`user_queue_token` is not null AND `dtp`.`queuedPlayer`.`user_id` = (SELECT `user_id` From `dtp`.`user` WHERE `user_token` = ?) ORDER BY `game_name` ASC ', [req.cookies.token], function (error, results, fields) {
                if (error) throw error
                else if (results[0] == undefined) {
                    console.log('DTPMyQueue: results undefined')
                    return res.send(pug.renderFile(process.cwd() + '/Templates/DTPMyQueues.pug', { queueList }))
                }
                else
                    //console.log("App Get: DTPMyQueues: Reached Here: " + results)
                    results.forEach(element => {
                        queue = {
                            'game_name': element.game_name,
                            'gamemode_name': element.gamemode_name,
                            'gamemode_nop': element.gamemode_nop,
                            'user_queue_token': element.user_queue_token
                        }
                        queueList.push(queue)
                    })
                //console.log(queueList)
                //console.log(pug.renderFile(process.cwd() + '/Templates/DTPMyQueues.pug', { queueList })) 
                res.send(pug.renderFile(process.cwd() + '/Templates/DTPMyQueues.pug', { queueList }))
            });
        }
    })


    app.get('/DTPGames.html', (req, res) => {
        if (req.requiresLogIn == true) {
            return res.redirect('/')
        }
        //console.log(req.cookies.token)
        var gameList = []
        connection.query('SELECT DISTINCT `game_name` FROM `dtp`.`game` ORDER BY `game_name` ASC ;', function (error, results, fields) {
            if (error) throw error
            else if (results[0] == undefined) {
                res.redirect('/DTPHome.html')
            }
            else {
                console.log("App Get: DTPGames: Reached Here")
                results.forEach(element => {
                    game = {
                        'game_name': element.game_name
                    }
                    //console.log(game.game_name + " & " + game.gamemode_name +  "|||")
                    gameList.push(game)
                })
                console.log(gameList)
                //console.log(pug.renderFile(process.cwd() + '/Templates/DTPMyQueues.pug', { gameAndGamemodeList }))
                // return res.send(pug.renderFile((process.cwd() + '/Templates/DTPQueueUp.pug'), { gameAndGamemodeList }))
                return res.send(pug.renderFile((process.cwd() + '/PUG/DTPGames.pug'), { gameList }))
            }
        });
        //res.sendFile(path.join(__dirname, "./HTML/DTPQueueUp.html"))
    })

    //app.get('/getusers', (req, res) => {

    //    connection.query('SELECT * FROM user', function (error, results, fields) {
    //        if (error) throw error;
    //        console.log('The solution is: ', results[0]);
    //        res.send(results[0])
    //    });

    //})

    //Route to 404, catch all
    app.get('/:route', (req, res) => {
        res.send('We aint got  ' + req.params.route + ' for youyou foo!');
        console.log(req.params)
    })

    //Posts for DTPSignIn.html 
    //Route to post /sign_in
    app.post('/sign_in', (req, res) => {
        connection.query('Select * FROM `dtp`.`user` WHERE `username`= ? AND `user_password` = ?;', [req.body.username, req.body.password], function (error, results, fields) {
            if (error) {
                res.send("Error");
            }
            else if (results[0] == undefined) {
                res.redirect('/DTPSignInError.html')
            }
            else {
                console.log('App Post: Sign In: User Crendentials Match');
                //activeUsers.push({userdata: results[0], token: token})
                // console.log(activeUsers)
                connection.query('UPDATE `dtp`.`user` SET user_token = ?, user_last_login = (NOW()) WHERE username = ?;', [req.cookies.token, results[0].username], function (error, results, fields) {
                    if (error) {
                        console.log('App Post: Sign In: If username is username attached to token: Error in token and datetime update')
                        res.redirect('/DTPRegisterError.html')
                    }
                    else {
                        res.redirect('/DTPHome.html')
                    }
                });
                //res.redirect('/DTPHome.html');
            }
        });
    })

    //posts for DTPRegister.html
    //route to post /add_user
    app.post('/create_account', (req, res) => {

        connection.query("INSERT INTO `dtp`.`user`(`username`, `user_email`, `user_password`) VALUES(?, ?, ?);", [req.body.username, req.body.email, req.body.password], function (error, results, fields) {
            if (error) {
                res.redirect('/DTPRegisterError.html')
            }
            else {
                res.redirect('/DTPSignInCreate.html')
            }
        });

    })
    //posts for DTPQueueUp.html
    //route to post /queue_up_host

    app.post('/queue_up', (req, res) => {
        var numberOfQueues = Object.keys(req.body).length
        var finishedQueues = [0, false]
        if (req.requiresLogIn == true) {
            return res.redirect('/')
        }
        else {
            console.log("App Post: Queue Up: Before Delete")
            //connection.query('DELETE FROM `dtp`.`queuedPlayer` WHERE (`user_queued_time`- NOW() < -3000) OR user_id = ?;', [req.user_id], function (error, deleteResults, fields) {
            connection.query('UPDATE queuedplayer AS QP, (SELECT user_queue_token FROM dtp.queuedplayer where user_id = ? AND user_is_host = 1) AS AP SET QP.user_queue_token = NULL WHERE QP.user_queue_token = AP.user_queue_token;', [req.user_id], function (error, updateResults, fields) {
                if (error) {
                    console.log("App Post: QueueUp: Error has occured in connection UPDATE Query")
                    console.log(error)
                }
                else {
                    console.log("App Post: QueueUp: Update setting player queue tokens to NULL successful")
                    connection.query('UPDATE queuedplayer AS QP SET QP.player_accepted_match = 0 WHERE QP.user_queue_token IS NULL;', function (error, results, fields) {
                        if (error) {
                            console.log("App Post: QueueUp: Update player_accepted_match to 0 error")
                        }
                        else {
                            connection.query('DELETE FROM `dtp`.`queuedPlayer` WHERE user_id = ?;', [req.user_id], function (error, deleteResults, fields) {
                                if (error) {
                                    console.log("App Post: QueueUp: Error has occured in connection DELETE query")
                                }
                                else {
                                    console.log("App Post: Queue Up: Queues for user deleted.")
                                    //console.log(results[0].user_last_login)
                                    //console.log(req.body)
                                    //console.log("AddingQueues:  " + Object.keys(req.body).length) 
                                    addingQueuesForEach(req, res, finishedQueues)
                                }
                            });
                        }
                    });

                }
            });
        }
        setTimeout(function () {
            if (finishedQueues[1] == false) {
                finishedQueues[1] = true
                //console.log("Timeout Reached")
                return res.redirect('/DTPMyQueues.html')
            }
        }, 0)
    })
    //connection.end();
    //app.listen(port, () => {
    //    console.log(`Example app listening at http://localhost:${port}`)
    //}) 

    http.listen(3000, () => {
        console.log('listening on *:3000');
    });