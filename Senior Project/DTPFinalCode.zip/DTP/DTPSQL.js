User = {
    matchToken: (connection, token, callback) => {
        connection.query(
            'Select `username`, `user_id`, `user_token`, (`user_last_login`- NOW()) AS TimeDiff FROM `dtp`.`user` WHERE `user_token`= ?;',
            token,
            (error, firstResults, fields) => {
                callback(error, firstResults, fields)
            })
    }
}

Queues = {
    deleteUsersQueues: () => { }
}

module.exports = {User:User}
