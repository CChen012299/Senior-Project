// JavaScript source code
var socket = io();
var username;
var hasAccepted;

socket.on('QFull', (msg) => {
    //var MessageBox = document.createElement('div');
    //window = document.getElementsByClassName('grid-conrainer-column')[0]
    ////window.appendChild(MessageBox)
    ////document.getElementsByClassName('staticDiv')[0].appendChild(MessageBox)

    popup = document.getElementById('staticDiv')
    popup.className = 'show'

    messageBoxes = document.getElementsByClassName('messageBox')
    acceptBtn = document.createElement('button')
    rejectBtn = document.createElement('button')

    acceptBtn.innerText = 'ACCEPT'
    rejectBtn.innerText = 'REJECT'

    acceptBtn.className = msg
    rejectBtn.className = msg

    acceptBtn.addEventListener('click', (e) => {
        console.log({ cookie: document.cookie, user_queue_token: e.target.classList[0], reply: 1 })
        socket.emit('acceptQ', { cookie: document.cookie, user_queue_token: e.target.classList[0], reply: 1 })
        console.log(e.target.parentElement.remove(e.target))
        popup.className = ''
    })

    rejectBtn.addEventListener('click', (e) => {
        console.log({ cookie: document.cookie, user_queue_token: e.target.classList[0], reply: 0 })
        socket.emit('rejectQ', { cookie: document.cookie, user_queue_token: e.target.classList[0], reply: 0 , username: username})
        console.log(e.target.parentElement.remove(e.target))
        popup.className = ''
    })

    messageBoxes[0].appendChild(acceptBtn)
    messageBoxes[0].appendChild(rejectBtn)
    console.log(popup, messageBoxes[0])
})



//socket.on('QFull', (msg) => {
//    alert("qFull")
//})

socket.on('test', (msg) => {
    console.log("msg")
})

socket.on('setUsername', (msg) => {
    console.log(msg)
    username = msg
})

socket.on('chat message', (msg) => {
    var item = document.createElement('div');
    item.textContent = msg.username + ": " + msg.message;
    chatbox = document.getElementsByClassName('chatbox ' + msg.roomToken)[0]
    chatbox.appendChild(item)
    chatbox.scrollTo(0, document.body.scrollHeight);
})



socket.emit('setup', document.cookie)
socket.on('refresh', () => {
    location.href = 'DTPMyQueues.html'
})

socket.on('refresh', (msg) => {
    alert(msg)
    location.href = 'DTPMyQueues.html'
})
//form.addEventListener('submit', function (e) {
//    e.preventDefault();
//    if (input.value) {
//        socket.emit('chat message', input.value);
//        input.value = '';
//    }
//});

//socket.on('chat message', function (msg) {
//    var item = document.createElement('li');
//    item.textContent = msg;
//    messages.appendChild(item);
//    window.scrollTo(0, document.body.scrollHeight);
//});

//var messages = document.getElementById('messages');
//var form = document.getElementById('form');
//var input = document.getElementById('input');
//let chatBoxes = document.getElementsByClassName('chatbox')
//if (chatBoxes[0] == undefined) {
//    console.log("undefined")
//    setTimeout(() => {
//        location.href = 'DTPMyQueues.html'
//    }, 10000)
//}
// get each input box
let inputBoxes = document.getElementsByClassName('input')


// get each send button
let sendButtonsElements = document.getElementsByClassName('send')
let sendButtons = []

for (let i = 0; i < sendButtonsElements.length; i++) {
    sendButtons[i] = sendButtonsElements[i]
}

console.log(sendButtons, sendButtonsElements)

sendButtons.forEach((element) => {
    //console.log(element)
    let roomToken = element.className.split(' ')[1]
    let input = document.getElementsByClassName('input ' + roomToken)[0]

        element.addEventListener('click', function (e) {
            e.preventDefault();
            console.log('Send Button pressed for ' + roomToken)
            if (input.value) {
                socket.emit('chat message', { username: username, roomToken: roomToken, message: input.value});
                input.value = '';
            }
        });
})

