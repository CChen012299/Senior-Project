// JavaScript source code
//Connections

var mysql = require('mysql');

var DTPSQL = require('./DTPSQL.js');
const { strMatchTokenUser } = require('./DTPSQL.js');

//Creates a connection to the MySQl Server
var connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '123321',
    database: 'dtp',
    insecureAuth: true
});

connection.connect();


var User = {
    getFriends: (token) => {
        return new Promise((suc, fail) => {
            connection.query('SELECT `dtp`.`user`.`username`, `dtp`.`user`.`user_email` FROM dtp.friend, dtp.user, (SELECT`dtp`.`user`.`user_id` FROM`dtp`.`user` WHERE`user_token` = ?) AS UserId WHERE(dtp.friend.user_id = UserId.user_id AND dtp.friend.friend_id = dtp.user.user_id) OR(dtp.friend.friend_id = UserId.user_id AND dtp.friend.user_id = dtp.user.user_id);', token, function (error, results, fields) {
                if (error) fail(error)

                else if (results[0] == undefined) {
                    console.log("error")
                    fail("undefined error")
                }
                else
                    console.log("Reached Here: " + results)

                var friendList = []

                results.forEach(element => {
                    friend = {
                        'friend_name': element.username,
                        'friend_email': element.user_email
                    }
                    friendList.push(friend)
                })
                //console.log(queueList)
                //console.log(pug.renderFile(process.cwd() + '/Templates/DTPMyQueues.pug', { queueList }))
                //return res.send(pug.renderFile((process.cwd() + '/Templates/DTPMyFriends.pug'), { friendList }))

                suc(friendList)
            });
        })
    },

    setUserTokenToNull: (userID) => {
        return new Promise((suc, fail) => {
            connection.query('UPDATE user SET user_token = null WHERE user_id = ?;', userID, function (error, userResults, fields) {
                if (error) {
                    //console.log("App Use: Login Session Expired: Error has occured in connection query")
                    fail("App Use: Login Session Expired: Error has occured in connection query")
                }
                else {
                    //console.log("App Use: Set user_token = null.")
                    suc("App Use: Set user_token = null.")
                }
            });
        });
    },

    updateUserLastLogin: (token) => {
        return new Promise((suc, fail) => {
            connection.query('UPDATE `dtp`.`user` SET user_last_login = (NOW()) WHERE `user_token` = ?;', token, function (error, results, fields) {
                if (error) {
                    //console.log('App Use: Error in token and datetime update')
                    fail('App Use: Error in token and datetime update')
                }
                else {
                    suc('Successfully updated user last login')
                }
            });
        });
    },

    getUserLoginData: (token) => {
        return new Promise((suc, fail) => {
            connection.query('Select `username`, `user_id`, `user_token`, (`user_last_login`- NOW()) AS TimeDiff FROM `dtp`.`user` WHERE `user_token`= ?;', token, function (error, firstResults, fields) {
                if (error) {
                    //console.log("App Use: Error has occured in connection query")
                    fail("App Use: Error has occured in connection query")
                }
                else if (firstResults[0] == undefined) {
                    //console.log("App Use: Results Undefined")
                    fail("App Use: Error has occured in connection query")
                }
                else {
                    suc(firstResults)
                }
            });
        });
    }
}


var Queue = {
    deleteUsersQueues: (userID) => {
        return new Promise((suc, fail) => {
            connection.query('DELETE FROM `dtp`.`queuedPlayer` WHERE user_id = ?;', [firstResults[0].user_id], function (error, userResults, fields) {
                if (error) {
                    //console.log("App Use: Delete: Error has occured in connection query")
                    fail("App Use: Delete: Error has occured in connection query")
                }
                else
                    //console.log("App Use: Queues for user deleted.")
                    suc("App Use: Queues for user deleted.")
            });
        });
    }
}




module.exports = {connection:connection, User:User, Queue:Queue }